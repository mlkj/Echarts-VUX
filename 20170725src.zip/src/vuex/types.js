//公共

export const COM_LOADING_STATUS = 'COM_LOADING_STATUS'       //loading状态


//user 用户
export const SET_USER_INFO      = 'SETUSERINFO'      //设置用户信息
export const GET_URL_DATA      = 'GET_URL_DATA'    //获取网址信息、登录状态
export const GET_USER_DATA      = 'GET_USER_DATA'    //获取用户信息
